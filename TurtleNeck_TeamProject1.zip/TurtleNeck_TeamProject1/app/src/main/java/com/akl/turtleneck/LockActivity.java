package com.akl.turtleneck;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.concurrent.locks.Lock;

public class LockActivity extends AppCompatActivity {
    //잠금화면

    int pageType = 1; //잠금화면으로 넘어올때 번호값

    String pw;
    int time=0;
    int img=0;//이미지 주소저장
    EditText edtLock;
    ImageView imgView;
    View vDialog;

    MyResultDBHelper mrhelper;
    SharedPreferences save;
    SharedPreferences.Editor editor;
    /* Intent intent = getIntent();
    String pw = intent.getStringExtra("PW");
    int time = intent.getIntExtra("TIME",0);*/
    @Override
    public void onBackPressed() {
        //뒤로가기버튼 무력화
    }


    @Override
    protected void onUserLeaveHint() {
        if(pageType==1){
            Toast.makeText(getApplicationContext(), "비밀번호가 입력되지않아 5초 후 재실행됩니다.",Toast.LENGTH_SHORT).show();
            Intent it2 = new Intent(this, LockActivity.class);
            it2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);//가장 최우선으로 보이기.
            startActivity(it2);

            //?서비스 추가 설정?
        }
    }


/*    @Override
    protected void onStart() {
        super.onStart();
        //서비스에서 보낸 항목 받아오기.
       *//* IntentFilter filt = new IntentFilter(MyIntentService.ACTION);
        LocalBroadcastManager.getInstance(this).registerReceiver(testReceiver,filt);*//*
    }*/

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if(pageType==1){
            Toast.makeText(getApplicationContext(), "비밀번호가 입력되지않아 5초 후 재실행됩니다.",Toast.LENGTH_SHORT).show();
            Intent it2 = new Intent(this, LockActivity.class);
            it2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);//가장 최우선으로 보이기.
            startActivity(it2);
        }else if (pageType==2){
            //finish가 입력될 경우 종료실행 반복
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);//잠금화면 해제, 이 액티비티가 먼저 화면에 나타나게 설정
        setContentView(R.layout.activity_lock);
        setTitle("잠금화면");

        //sharedPreferences호출

        //다이얼로그 xml 만들 것.
        //푸쉬바 설정 할것.

        save = getSharedPreferences("save",MODE_PRIVATE);
        img=save.getInt("IMG",0);//이미지 주소

        vDialog=(View)View.inflate(LockActivity.this, R.layout.dialog, null);

        edtLock=vDialog.findViewById(R.id.edtLock);
        imgView=vDialog.findViewById(R.id.imgView);
        imgView.setImageResource(img);

        AlertDialog.Builder builder = new AlertDialog.Builder(LockActivity.this);
        builder.setTitle("잠금화면").setCancelable(false)//다이얼로그 밖 터치시 취소 금지
        .setView(vDialog)
        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //이 항목에 로그인창을 만들경우, 잘못된 값이어도 종료버튼을 누르면 취소됨.
                //아래 다이얼로그 새로 설정 후 버튼 항목 새로 설정
            }
        });//확인버튼
        final AlertDialog dlg = builder.create();
        dlg.show();

        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pass = edtLock.getText().toString();
                String sqpass = null;

                time= save.getInt("icnt",0);//사용시간
                pw=save.getString("PW","");//비밀번호

                sqpass=pw;

                if(pass.equals(sqpass)){//db의 비밀번호와 값이 같다면.
                    Toast.makeText(getApplicationContext(), "확인되었습니다.",Toast.LENGTH_SHORT).show();
                    dlg.dismiss();

                    Intent it = new Intent(LockActivity.this, Main2Activity.class);
                    //it.putExtra("TYPE", "2");
                    pageType=2;

                    //db에 저장.(만들것.)

                    startActivity(it);

                    finish();

                }else{
                    Toast.makeText(getApplicationContext(), "잘못 입력하셨습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });//확인버튼 메소드설정

    }//onCreate end

    public void timeinsDB(int i){
        //사용시간(time값), 현재 날짜(연,월,일) db등록

    }

}//main end
